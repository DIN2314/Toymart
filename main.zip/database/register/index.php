<form method="post">
    <p>User Name: <input type="text" name="txtLNME" id="id_txtLNME"></p>
    <p>First Name: <input type="text" name="txtFNME" id="id_txtFNME"> Middle Name: <input type="text" name="txtMNME" id="id_txtMNME"></p>
    <p>Last Name: <input type="text" name="txtLNME" id="id_txtLNME"></p><br>

    <p>Gender: <select name="lstGNDR" id="id_lstGNDR"><option>Male</option><option>Female</option></select></p>
    <p>Date of Birth: <input type="date" name="datDOB" id="id_datDOB"></p>

    <p>E Mail: <input type="text" name="txtEMAIL" id="id_txtEMAIL"></p>
    <p>Password: <input type="Password" name="txtPWD" id="id_txtPWD"></p>
    <p>Confirm - Password: <input type="Password" name="txtCPWD" id="id_txtCPWD"></p><br>
    <p><input type="checkbox" name="chkACCLIC" id="id_chkACCLIC" > I Accept The License Agreement.</p><br>
    <input type="button" value="Register" name="butREG" id="id_butREG">
</form>

<?php

?>